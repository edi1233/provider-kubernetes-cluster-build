package kubernetescluster

import (
	"testing"

	xpv1 "github.com/crossplane/crossplane-runtime/apis/common/v1"

	"github.com/airuneers/provider-kubernetes-cluster/apis/v1alpha1"
)

func TestValidate(t *testing.T) {
	base := &v1alpha1.KubernetesCluster{
		Spec: v1alpha1.KubernetesClusterSpec{
			ForProvider: v1alpha1.KubernetesClusterParameters{
				Name:         "lab",
				Version:      "v1.34.1+k0s",
				Distribution: v1alpha1.DistributionK0s,
				Backend: v1alpha1.ClusterBackendSpec{
					Type: v1alpha1.BackendProxmox,
					Proxmox: &v1alpha1.ProxmoxBackendSpec{
						ProviderConfigRef: xpv1.Reference{Name: "proxmox"},
					},
				},
				ControlPlane: v1alpha1.NodePoolSpec{Replicas: 1},
			},
		},
	}
	if err := validate(base); err != nil {
		t.Fatalf("validate returned error: %v", err)
	}
	base.Spec.ForProvider.Backend.Proxmox.ProviderConfigRef.Name = ""
	if err := validate(base); err == nil {
		t.Fatal("validate succeeded without proxmox providerConfigRef")
	}
}

func TestPhase(t *testing.T) {
	if got := phase(Observation{Ready: true}); got != v1alpha1.ClusterPhaseReady {
		t.Fatalf("ready phase = %q", got)
	}
	if got := phase(Observation{}); got != v1alpha1.ClusterPhasePending {
		t.Fatalf("pending phase = %q", got)
	}
}
