package kubernetescluster

import (
	"context"
	"fmt"

	xpv1 "github.com/crossplane/crossplane-runtime/apis/common/v1"
	"github.com/crossplane/crossplane-runtime/pkg/meta"
	"github.com/crossplane/crossplane-runtime/pkg/reconciler/managed"
	"github.com/crossplane/crossplane-runtime/pkg/resource"
	ctrl "sigs.k8s.io/controller-runtime"

	"github.com/airuneers/provider-kubernetes-cluster/apis/v1alpha1"
)

type clusterPlanner interface {
	Observe(context.Context, *v1alpha1.KubernetesCluster) (Observation, error)
	Apply(context.Context, *v1alpha1.KubernetesCluster) (ActionResult, error)
	Delete(context.Context, *v1alpha1.KubernetesCluster) error
}

type Observation struct {
	Exists             bool
	UpToDate           bool
	Ready              bool
	Endpoint           string
	ReadyControlPlanes int
	ReadyWorkers       int
	NodeNames          []string
	LastAction         string
}

type ActionResult struct {
	Action string
}

type connector struct {
	planner clusterPlanner
}

type external struct {
	planner clusterPlanner
}

func Setup(mgr ctrl.Manager) error {
	name := managed.ControllerName("KubernetesCluster")
	r := managed.NewReconciler(
		mgr,
		resource.ManagedKind(v1alpha1.GroupVersion.WithKind("KubernetesCluster")),
		managed.WithExternalConnecter(&connector{planner: noopPlanner{}}),
	)
	return ctrl.NewControllerManagedBy(mgr).
		Named(name).
		For(&v1alpha1.KubernetesCluster{}).
		Complete(r)
}

func (c *connector) Connect(ctx context.Context, mg resource.Managed) (managed.ExternalClient, error) {
	cluster, err := asCluster(mg)
	if err != nil {
		return nil, err
	}
	if err := validate(cluster); err != nil {
		return nil, err
	}
	return &external{planner: c.planner}, nil
}

func (e *external) Observe(ctx context.Context, mg resource.Managed) (managed.ExternalObservation, error) {
	cluster, err := asCluster(mg)
	if err != nil {
		return managed.ExternalObservation{}, err
	}
	obs, err := e.planner.Observe(ctx, cluster)
	if err != nil {
		return managed.ExternalObservation{}, err
	}
	cluster.Status.AtProvider = v1alpha1.KubernetesClusterObservation{
		Phase:               phase(obs),
		Version:             cluster.Spec.ForProvider.Version,
		Endpoint:            obs.Endpoint,
		ReadyControlPlanes:  obs.ReadyControlPlanes,
		ReadyWorkers:        obs.ReadyWorkers,
		NodeNames:           append([]string(nil), obs.NodeNames...),
		LastBootstrapAction: obs.LastAction,
	}
	if obs.Ready {
		cluster.SetConditions(xpv1.Available())
	} else {
		cluster.SetConditions(xpv1.Creating())
	}
	return managed.ExternalObservation{
		ResourceExists:    obs.Exists,
		ResourceUpToDate:  obs.UpToDate,
		ConnectionDetails: kubeconfigConnectionDetails(cluster),
	}, nil
}

func (e *external) Create(ctx context.Context, mg resource.Managed) (managed.ExternalCreation, error) {
	cluster, err := asCluster(mg)
	if err != nil {
		return managed.ExternalCreation{}, err
	}
	result, err := e.planner.Apply(ctx, cluster)
	if err != nil {
		return managed.ExternalCreation{}, err
	}
	meta.SetExternalName(cluster, cluster.Spec.ForProvider.Name)
	return managed.ExternalCreation{
		AdditionalDetails: managed.AdditionalDetails{"action": result.Action},
	}, nil
}

func (e *external) Update(ctx context.Context, mg resource.Managed) (managed.ExternalUpdate, error) {
	cluster, err := asCluster(mg)
	if err != nil {
		return managed.ExternalUpdate{}, err
	}
	result, err := e.planner.Apply(ctx, cluster)
	if err != nil {
		return managed.ExternalUpdate{}, err
	}
	return managed.ExternalUpdate{
		AdditionalDetails: managed.AdditionalDetails{"action": result.Action},
	}, nil
}

func (e *external) Delete(ctx context.Context, mg resource.Managed) (managed.ExternalDelete, error) {
	cluster, err := asCluster(mg)
	if err != nil {
		return managed.ExternalDelete{}, err
	}
	return managed.ExternalDelete{}, e.planner.Delete(ctx, cluster)
}

func (e *external) Disconnect(ctx context.Context) error { return nil }

func asCluster(mg resource.Managed) (*v1alpha1.KubernetesCluster, error) {
	cluster, ok := mg.(*v1alpha1.KubernetesCluster)
	if !ok {
		return nil, fmt.Errorf("managed resource is %T, want *KubernetesCluster", mg)
	}
	return cluster, nil
}

func validate(cluster *v1alpha1.KubernetesCluster) error {
	p := cluster.Spec.ForProvider
	if p.Name == "" {
		return fmt.Errorf("spec.forProvider.name is required")
	}
	if p.Version == "" {
		return fmt.Errorf("spec.forProvider.version is required")
	}
	if p.Distribution != "" && p.Distribution != v1alpha1.DistributionK0s {
		return fmt.Errorf("unsupported distribution %q", p.Distribution)
	}
	if p.ControlPlane.Replicas < 1 {
		return fmt.Errorf("spec.forProvider.controlPlane.replicas must be at least 1")
	}
	switch p.Backend.Type {
	case v1alpha1.BackendProxmox:
		if p.Backend.Proxmox == nil || p.Backend.Proxmox.ProviderConfigRef.Name == "" {
			return fmt.Errorf("proxmox backend requires providerConfigRef.name")
		}
	case v1alpha1.BackendVSphere:
		if p.Backend.VSphere == nil || p.Backend.VSphere.ProviderConfigRef.Name == "" {
			return fmt.Errorf("vsphere backend requires providerConfigRef.name")
		}
	default:
		return fmt.Errorf("unsupported backend type %q", p.Backend.Type)
	}
	return nil
}

func phase(obs Observation) string {
	if obs.Ready {
		return v1alpha1.ClusterPhaseReady
	}
	return v1alpha1.ClusterPhasePending
}

func kubeconfigConnectionDetails(cluster *v1alpha1.KubernetesCluster) managed.ConnectionDetails {
	if cluster.Status.AtProvider.Endpoint == "" {
		return nil
	}
	return managed.ConnectionDetails{
		"endpoint": []byte(cluster.Status.AtProvider.Endpoint),
	}
}

type noopPlanner struct{}

func (noopPlanner) Observe(ctx context.Context, cluster *v1alpha1.KubernetesCluster) (Observation, error) {
	return Observation{Exists: meta.GetExternalName(cluster) != "", UpToDate: false, LastAction: "waiting-for-bootstrap-implementation"}, nil
}

func (noopPlanner) Apply(ctx context.Context, cluster *v1alpha1.KubernetesCluster) (ActionResult, error) {
	return ActionResult{Action: "planned-k0s-bootstrap"}, nil
}

func (noopPlanner) Delete(ctx context.Context, cluster *v1alpha1.KubernetesCluster) error {
	return nil
}
