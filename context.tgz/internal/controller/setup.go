package controller

import (
	"github.com/airuneers/provider-kubernetes-cluster/internal/controller/kubernetescluster"
	ctrl "sigs.k8s.io/controller-runtime"
)

func Setup(mgr ctrl.Manager) error {
	return kubernetescluster.Setup(mgr)
}
