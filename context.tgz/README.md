# provider-kubernetes-cluster

Crossplane provider for declarative Kubernetes cluster provisioning.

The first API target is `KubernetesCluster` with k0s-first bootstrap semantics and backend references for Proxmox and vSphere.

```yaml
apiVersion: kubernetescluster.crossplane.io/v1alpha1
kind: KubernetesCluster
metadata:
  name: lab-k0s
spec:
  forProvider:
    name: lab-k0s
    distribution: k0s
    version: v1.34.1+k0s
    backend:
      type: proxmox
      proxmox:
        providerConfigRef:
          name: default
    controlPlane:
      replicas: 1
```

See `docs/kubernetes-provider-architecture.md` for the initial API and reconciliation design.
