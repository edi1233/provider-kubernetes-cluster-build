package version

var (
	Version = "0.1.0-dev"
	Commit  = "unknown"
	Date    = "unknown"
)
