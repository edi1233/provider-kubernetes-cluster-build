package v1alpha1

import (
	xpv1 "github.com/crossplane/crossplane-runtime/apis/common/v1"
	"github.com/crossplane/crossplane-runtime/pkg/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
)

var _ resource.ProviderConfigUsage = (*ProviderConfigUsage)(nil)
var _ resource.ProviderConfigUsageList = (*ProviderConfigUsageList)(nil)

type ProviderConfigUsageSpec struct {
	xpv1.ProviderConfigUsage `json:",inline"`
}

// +kubebuilder:object:root=true
// +kubebuilder:resource:scope=Cluster,categories={crossplane,provider,kubernetescluster}
type ProviderConfigUsage struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`
	Spec              ProviderConfigUsageSpec `json:"spec"`
}

// +kubebuilder:object:root=true
type ProviderConfigUsageList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []ProviderConfigUsage `json:"items"`
}

func (in *ProviderConfigUsage) SetProviderConfigReference(p xpv1.Reference) {
	in.Spec.ProviderConfigReference = p
}

func (in *ProviderConfigUsage) GetProviderConfigReference() xpv1.Reference {
	return in.Spec.ProviderConfigReference
}

func (in *ProviderConfigUsage) SetResourceReference(r xpv1.TypedReference) {
	in.Spec.ResourceReference = r
}

func (in *ProviderConfigUsage) GetResourceReference() xpv1.TypedReference {
	return in.Spec.ResourceReference
}

func (in *ProviderConfigUsageList) GetItems() []resource.ProviderConfigUsage {
	items := make([]resource.ProviderConfigUsage, len(in.Items))
	for i := range in.Items {
		items[i] = &in.Items[i]
	}
	return items
}

func (in *ProviderConfigUsageSpec) DeepCopyInto(out *ProviderConfigUsageSpec) {
	*out = *in
	in.ProviderConfigUsage.DeepCopyInto(&out.ProviderConfigUsage)
}

func (in *ProviderConfigUsageSpec) DeepCopy() *ProviderConfigUsageSpec {
	if in == nil {
		return nil
	}
	out := new(ProviderConfigUsageSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *ProviderConfigUsage) DeepCopyInto(out *ProviderConfigUsage) {
	*out = *in
	out.TypeMeta = in.TypeMeta
	in.ObjectMeta.DeepCopyInto(&out.ObjectMeta)
	in.Spec.DeepCopyInto(&out.Spec)
}

func (in *ProviderConfigUsage) DeepCopy() *ProviderConfigUsage {
	if in == nil {
		return nil
	}
	out := new(ProviderConfigUsage)
	in.DeepCopyInto(out)
	return out
}

func (in *ProviderConfigUsage) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	return in.DeepCopy()
}

func (in *ProviderConfigUsageList) DeepCopyInto(out *ProviderConfigUsageList) {
	*out = *in
	out.TypeMeta = in.TypeMeta
	in.ListMeta.DeepCopyInto(&out.ListMeta)
	if in.Items != nil {
		out.Items = make([]ProviderConfigUsage, len(in.Items))
		for i := range in.Items {
			in.Items[i].DeepCopyInto(&out.Items[i])
		}
	}
}

func (in *ProviderConfigUsageList) DeepCopy() *ProviderConfigUsageList {
	if in == nil {
		return nil
	}
	out := new(ProviderConfigUsageList)
	in.DeepCopyInto(out)
	return out
}

func (in *ProviderConfigUsageList) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	return in.DeepCopy()
}
