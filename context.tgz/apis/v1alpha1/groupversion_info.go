package v1alpha1

import (
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
	"k8s.io/apimachinery/pkg/runtime/schema"
	ctrl "sigs.k8s.io/controller-runtime"
)

const (
	Group   = "kubernetescluster.crossplane.io"
	Version = "v1alpha1"
)

var (
	GroupVersion  = schema.GroupVersion{Group: Group, Version: Version}
	SchemeBuilder = runtime.NewSchemeBuilder(addKnownTypes)
	AddToScheme   = SchemeBuilder.AddToScheme
)

func addKnownTypes(scheme *runtime.Scheme) error {
	scheme.AddKnownTypes(
		GroupVersion,
		&ProviderConfig{},
		&ProviderConfigList{},
		&ProviderConfigUsage{},
		&ProviderConfigUsageList{},
		&KubernetesCluster{},
		&KubernetesClusterList{},
	)
	metav1.AddToGroupVersion(scheme, GroupVersion)
	return nil
}

func SetupWebhookWithManager(mgr ctrl.Manager) error {
	return nil
}
