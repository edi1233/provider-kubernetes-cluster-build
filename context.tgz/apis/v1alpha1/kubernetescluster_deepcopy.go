package v1alpha1

import xpv1 "github.com/crossplane/crossplane-runtime/apis/common/v1"

func (in *KubernetesClusterSpec) DeepCopyInto(out *KubernetesClusterSpec) {
	*out = *in
	in.ResourceSpec.DeepCopyInto(&out.ResourceSpec)
	in.ForProvider.DeepCopyInto(&out.ForProvider)
}

func (in *KubernetesClusterSpec) DeepCopy() *KubernetesClusterSpec {
	if in == nil {
		return nil
	}
	out := new(KubernetesClusterSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *KubernetesClusterParameters) DeepCopyInto(out *KubernetesClusterParameters) {
	*out = *in
	in.Backend.DeepCopyInto(&out.Backend)
	in.ControlPlane.DeepCopyInto(&out.ControlPlane)
	if in.Workers != nil {
		out.Workers = make([]NodePoolSpec, len(in.Workers))
		for i := range in.Workers {
			in.Workers[i].DeepCopyInto(&out.Workers[i])
		}
	}
	in.Network.DeepCopyInto(&out.Network)
	in.Bootstrap.DeepCopyInto(&out.Bootstrap)
	in.Addons.DeepCopyInto(&out.Addons)
	in.Kubeconfig.DeepCopyInto(&out.Kubeconfig)
}

func (in *KubernetesClusterParameters) DeepCopy() *KubernetesClusterParameters {
	if in == nil {
		return nil
	}
	out := new(KubernetesClusterParameters)
	in.DeepCopyInto(out)
	return out
}

func (in *ClusterBackendSpec) DeepCopyInto(out *ClusterBackendSpec) {
	*out = *in
	if in.Proxmox != nil {
		out.Proxmox = new(ProxmoxBackendSpec)
		in.Proxmox.DeepCopyInto(out.Proxmox)
	}
	if in.VSphere != nil {
		out.VSphere = new(VSphereBackendSpec)
		in.VSphere.DeepCopyInto(out.VSphere)
	}
}

func (in *ClusterBackendSpec) DeepCopy() *ClusterBackendSpec {
	if in == nil {
		return nil
	}
	out := new(ClusterBackendSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *ProxmoxBackendSpec) DeepCopyInto(out *ProxmoxBackendSpec) { *out = *in }
func (in *ProxmoxBackendSpec) DeepCopy() *ProxmoxBackendSpec {
	if in == nil {
		return nil
	}
	out := new(ProxmoxBackendSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *VSphereBackendSpec) DeepCopyInto(out *VSphereBackendSpec) { *out = *in }
func (in *VSphereBackendSpec) DeepCopy() *VSphereBackendSpec {
	if in == nil {
		return nil
	}
	out := new(VSphereBackendSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *NodePoolSpec) DeepCopyInto(out *NodePoolSpec) {
	*out = *in
	if in.Addresses != nil {
		out.Addresses = append([]string(nil), in.Addresses...)
	}
}

func (in *NodePoolSpec) DeepCopy() *NodePoolSpec {
	if in == nil {
		return nil
	}
	out := new(NodePoolSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *ClusterNetworkSpec) DeepCopyInto(out *ClusterNetworkSpec) {
	*out = *in
	if in.ClusterDNS != nil {
		out.ClusterDNS = append([]string(nil), in.ClusterDNS...)
	}
}

func (in *ClusterNetworkSpec) DeepCopy() *ClusterNetworkSpec {
	if in == nil {
		return nil
	}
	out := new(ClusterNetworkSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *ClusterBootstrapSpec) DeepCopyInto(out *ClusterBootstrapSpec) {
	*out = *in
	if in.SSHPrivateKeyRef != nil {
		out.SSHPrivateKeyRef = new(xpv1.SecretKeySelector)
		in.SSHPrivateKeyRef.DeepCopyInto(out.SSHPrivateKeyRef)
	}
	if in.InstallFlags != nil {
		out.InstallFlags = append([]string(nil), in.InstallFlags...)
	}
	if in.JoinTokenSecretRef != nil {
		out.JoinTokenSecretRef = new(xpv1.SecretKeySelector)
		in.JoinTokenSecretRef.DeepCopyInto(out.JoinTokenSecretRef)
	}
}

func (in *ClusterBootstrapSpec) DeepCopy() *ClusterBootstrapSpec {
	if in == nil {
		return nil
	}
	out := new(ClusterBootstrapSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *ClusterAddonsSpec) DeepCopyInto(out *ClusterAddonsSpec) {
	*out = *in
	if in.MetalLB != nil {
		out.MetalLB = new(MetalLBSpec)
		in.MetalLB.DeepCopyInto(out.MetalLB)
	}
}

func (in *ClusterAddonsSpec) DeepCopy() *ClusterAddonsSpec {
	if in == nil {
		return nil
	}
	out := new(ClusterAddonsSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *MetalLBSpec) DeepCopyInto(out *MetalLBSpec) {
	*out = *in
	if in.AddressPools != nil {
		out.AddressPools = append([]string(nil), in.AddressPools...)
	}
}

func (in *MetalLBSpec) DeepCopy() *MetalLBSpec {
	if in == nil {
		return nil
	}
	out := new(MetalLBSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *KubeconfigPublishSpec) DeepCopyInto(out *KubeconfigPublishSpec) {
	*out = *in
	in.SecretRef.DeepCopyInto(&out.SecretRef)
}

func (in *KubeconfigPublishSpec) DeepCopy() *KubeconfigPublishSpec {
	if in == nil {
		return nil
	}
	out := new(KubeconfigPublishSpec)
	in.DeepCopyInto(out)
	return out
}

func (in *KubernetesClusterStatus) DeepCopyInto(out *KubernetesClusterStatus) {
	*out = *in
	in.ResourceStatus.DeepCopyInto(&out.ResourceStatus)
	in.AtProvider.DeepCopyInto(&out.AtProvider)
}

func (in *KubernetesClusterStatus) DeepCopy() *KubernetesClusterStatus {
	if in == nil {
		return nil
	}
	out := new(KubernetesClusterStatus)
	in.DeepCopyInto(out)
	return out
}

func (in *KubernetesClusterObservation) DeepCopyInto(out *KubernetesClusterObservation) {
	*out = *in
	if in.NodeNames != nil {
		out.NodeNames = append([]string(nil), in.NodeNames...)
	}
}

func (in *KubernetesClusterObservation) DeepCopy() *KubernetesClusterObservation {
	if in == nil {
		return nil
	}
	out := new(KubernetesClusterObservation)
	in.DeepCopyInto(out)
	return out
}

func (in *KubernetesCluster) DeepCopyInto(out *KubernetesCluster) {
	*out = *in
	out.TypeMeta = in.TypeMeta
	in.ObjectMeta.DeepCopyInto(&out.ObjectMeta)
	in.Spec.DeepCopyInto(&out.Spec)
	in.Status.DeepCopyInto(&out.Status)
}

func (in *KubernetesCluster) DeepCopy() *KubernetesCluster {
	if in == nil {
		return nil
	}
	out := new(KubernetesCluster)
	in.DeepCopyInto(out)
	return out
}

func (in *KubernetesClusterList) DeepCopyInto(out *KubernetesClusterList) {
	*out = *in
	out.TypeMeta = in.TypeMeta
	in.ListMeta.DeepCopyInto(&out.ListMeta)
	if in.Items != nil {
		out.Items = make([]KubernetesCluster, len(in.Items))
		for i := range in.Items {
			in.Items[i].DeepCopyInto(&out.Items[i])
		}
	}
}

func (in *KubernetesClusterList) DeepCopy() *KubernetesClusterList {
	if in == nil {
		return nil
	}
	out := new(KubernetesClusterList)
	in.DeepCopyInto(out)
	return out
}
