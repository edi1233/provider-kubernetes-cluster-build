package v1alpha1

import (
	xpv1 "github.com/crossplane/crossplane-runtime/apis/common/v1"
	"github.com/crossplane/crossplane-runtime/pkg/resource"
	metav1 "k8s.io/apimachinery/pkg/apis/meta/v1"
	"k8s.io/apimachinery/pkg/runtime"
)

var _ resource.Managed = (*KubernetesCluster)(nil)

const (
	DistributionK0s     = "k0s"
	BackendProxmox      = "proxmox"
	BackendVSphere      = "vsphere"
	ClusterPhasePending = "Pending"
	ClusterPhaseReady   = "Ready"
)

type KubernetesClusterSpec struct {
	xpv1.ResourceSpec `json:",inline"`
	ForProvider       KubernetesClusterParameters `json:"forProvider"`
}

type KubernetesClusterParameters struct {
	Name         string                `json:"name"`
	Version      string                `json:"version"`
	Distribution string                `json:"distribution,omitempty"`
	Backend      ClusterBackendSpec    `json:"backend"`
	ControlPlane NodePoolSpec          `json:"controlPlane"`
	Workers      []NodePoolSpec        `json:"workers,omitempty"`
	Network      ClusterNetworkSpec    `json:"network,omitempty"`
	Bootstrap    ClusterBootstrapSpec  `json:"bootstrap,omitempty"`
	Addons       ClusterAddonsSpec     `json:"addons,omitempty"`
	Kubeconfig   KubeconfigPublishSpec `json:"kubeconfig,omitempty"`
}

type ClusterBackendSpec struct {
	Type    string              `json:"type"`
	Proxmox *ProxmoxBackendSpec `json:"proxmox,omitempty"`
	VSphere *VSphereBackendSpec `json:"vsphere,omitempty"`
}

type ProxmoxBackendSpec struct {
	ProviderConfigRef xpv1.Reference `json:"providerConfigRef"`
	Node              string         `json:"node,omitempty"`
	Template          string         `json:"template,omitempty"`
	Storage           string         `json:"storage,omitempty"`
	NetworkBridge     string         `json:"networkBridge,omitempty"`
}

type VSphereBackendSpec struct {
	ProviderConfigRef xpv1.Reference `json:"providerConfigRef"`
	Datacenter        string         `json:"datacenter,omitempty"`
	Cluster           string         `json:"cluster,omitempty"`
	Datastore         string         `json:"datastore,omitempty"`
	Network           string         `json:"network,omitempty"`
	Template          string         `json:"template,omitempty"`
}

type NodePoolSpec struct {
	Name      string   `json:"name,omitempty"`
	Replicas  int      `json:"replicas"`
	Cores     int      `json:"cores,omitempty"`
	MemoryMiB int      `json:"memoryMiB,omitempty"`
	DiskGiB   int      `json:"diskGiB,omitempty"`
	Addresses []string `json:"addresses,omitempty"`
}

type ClusterNetworkSpec struct {
	PodCIDR        string   `json:"podCIDR,omitempty"`
	ServiceCIDR    string   `json:"serviceCIDR,omitempty"`
	ClusterDNS     []string `json:"clusterDNS,omitempty"`
	APIServerVIP   string   `json:"apiServerVIP,omitempty"`
	LoadBalancerIP string   `json:"loadBalancerIP,omitempty"`
}

type ClusterBootstrapSpec struct {
	SSHUser            string                  `json:"sshUser,omitempty"`
	SSHPrivateKeyRef   *xpv1.SecretKeySelector `json:"sshPrivateKeyRef,omitempty"`
	TimeoutSeconds     int                     `json:"timeoutSeconds,omitempty"`
	ExtraK0sConfig     string                  `json:"extraK0sConfig,omitempty"`
	InstallFlags       []string                `json:"installFlags,omitempty"`
	JoinTokenSecretRef *xpv1.SecretKeySelector `json:"joinTokenSecretRef,omitempty"`
}

type ClusterAddonsSpec struct {
	CNI     string       `json:"cni,omitempty"`
	MetalLB *MetalLBSpec `json:"metalLB,omitempty"`
}

type MetalLBSpec struct {
	AddressPools []string `json:"addressPools,omitempty"`
}

type KubeconfigPublishSpec struct {
	SecretRef xpv1.SecretReference `json:"secretRef,omitempty"`
}

type KubernetesClusterStatus struct {
	xpv1.ResourceStatus `json:",inline"`
	AtProvider          KubernetesClusterObservation `json:"atProvider,omitempty"`
}

type KubernetesClusterObservation struct {
	Phase               string   `json:"phase,omitempty"`
	Version             string   `json:"version,omitempty"`
	Endpoint            string   `json:"endpoint,omitempty"`
	ReadyControlPlanes  int      `json:"readyControlPlanes,omitempty"`
	ReadyWorkers        int      `json:"readyWorkers,omitempty"`
	NodeNames           []string `json:"nodeNames,omitempty"`
	LastBootstrapAction string   `json:"lastBootstrapAction,omitempty"`
}

// +kubebuilder:object:root=true
// +kubebuilder:subresource:status
// +kubebuilder:resource:scope=Cluster,categories={crossplane,managed,kubernetescluster}
// +kubebuilder:printcolumn:name="READY",type="string",JSONPath=".status.conditions[?(@.type=='Ready')].status"
// +kubebuilder:printcolumn:name="SYNCED",type="string",JSONPath=".status.conditions[?(@.type=='Synced')].status"
// +kubebuilder:printcolumn:name="VERSION",type="string",JSONPath=".spec.forProvider.version"
// +kubebuilder:printcolumn:name="DIST",type="string",JSONPath=".spec.forProvider.distribution"
// +kubebuilder:printcolumn:name="PHASE",type="string",JSONPath=".status.atProvider.phase"
// +kubebuilder:printcolumn:name="AGE",type="date",JSONPath=".metadata.creationTimestamp"
type KubernetesCluster struct {
	metav1.TypeMeta   `json:",inline"`
	metav1.ObjectMeta `json:"metadata,omitempty"`

	Spec   KubernetesClusterSpec   `json:"spec"`
	Status KubernetesClusterStatus `json:"status,omitempty"`
}

// +kubebuilder:object:root=true
type KubernetesClusterList struct {
	metav1.TypeMeta `json:",inline"`
	metav1.ListMeta `json:"metadata,omitempty"`
	Items           []KubernetesCluster `json:"items"`
}

func (in *KubernetesCluster) SetConditions(c ...xpv1.Condition) { in.Status.SetConditions(c...) }
func (in *KubernetesCluster) GetCondition(ct xpv1.ConditionType) xpv1.Condition {
	return in.Status.GetCondition(ct)
}
func (in *KubernetesCluster) SetProviderConfigReference(r *xpv1.Reference) {
	in.Spec.ProviderConfigReference = r
}
func (in *KubernetesCluster) GetProviderConfigReference() *xpv1.Reference {
	return in.Spec.ProviderConfigReference
}
func (in *KubernetesCluster) SetWriteConnectionSecretToReference(r *xpv1.SecretReference) {
	in.Spec.WriteConnectionSecretToReference = r
}
func (in *KubernetesCluster) GetWriteConnectionSecretToReference() *xpv1.SecretReference {
	return in.Spec.WriteConnectionSecretToReference
}
func (in *KubernetesCluster) SetPublishConnectionDetailsTo(r *xpv1.PublishConnectionDetailsTo) {
	in.Spec.PublishConnectionDetailsTo = r
}
func (in *KubernetesCluster) GetPublishConnectionDetailsTo() *xpv1.PublishConnectionDetailsTo {
	return in.Spec.PublishConnectionDetailsTo
}
func (in *KubernetesCluster) SetManagementPolicies(p xpv1.ManagementPolicies) {
	in.Spec.ManagementPolicies = p
}
func (in *KubernetesCluster) GetManagementPolicies() xpv1.ManagementPolicies {
	return in.Spec.ManagementPolicies
}
func (in *KubernetesCluster) SetDeletionPolicy(p xpv1.DeletionPolicy) { in.Spec.DeletionPolicy = p }
func (in *KubernetesCluster) GetDeletionPolicy() xpv1.DeletionPolicy  { return in.Spec.DeletionPolicy }

func (in *KubernetesClusterList) GetItems() []resource.Managed {
	items := make([]resource.Managed, len(in.Items))
	for i := range in.Items {
		items[i] = &in.Items[i]
	}
	return items
}

func (in *KubernetesCluster) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	return in.DeepCopy()
}

func (in *KubernetesClusterList) DeepCopyObject() runtime.Object {
	if in == nil {
		return nil
	}
	return in.DeepCopy()
}
