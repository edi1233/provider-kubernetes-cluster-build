# Kubernetes Cluster Provider Architecture

`provider-kubernetes-cluster` exposes a Crossplane managed resource for provisioning Kubernetes clusters with selectable distribution, version, topology, backend, and bootstrap configuration.

The first implementation target is k0s because it has a compact bootstrap surface, supports explicit Kubernetes versions through `k0s` releases, and has already been proven in the Proxmox lab. The API leaves room for `kubeadm`, `rke2`, and Talos without blocking the first usable version.

## Provider Boundary

This provider owns Kubernetes cluster lifecycle semantics. It does not duplicate every VM lifecycle operation already present in `provider-proxmox` and `provider-vsphere`.

The first backend design references existing backend providers through `providerConfigRef` plus backend defaults:

- `backend.type: proxmox` references a Proxmox provider config and template/node defaults.
- `backend.type: vsphere` references a vSphere provider config and template/datacenter defaults.
- Cluster node pools describe the desired control plane and worker shapes.
- The controller can later create backend `VirtualMachine` managed resources or bind to composition-generated VM resources.

This keeps the user-facing API stable while allowing either direct child-resource creation or Crossplane Compositions underneath.

## API Surface

Primary managed resource:

- `KubernetesCluster.kubernetescluster.crossplane.io/v1alpha1`

Required fields:

- `spec.forProvider.name`
- `spec.forProvider.version`
- `spec.forProvider.backend.type`
- backend-specific `providerConfigRef.name`
- `spec.forProvider.controlPlane.replicas`

Important optional fields:

- `distribution`, defaulting to `k0s`
- worker pools with `replicas`, `cores`, `memoryMiB`, `diskGiB`, and static addresses
- network CIDRs, API server VIP, and load balancer IP
- SSH bootstrap user/key, k0s config, install flags, and join-token secret references
- CNI and MetalLB addon settings
- kubeconfig output secret reference

## Reconciliation Phases

1. Validate the cluster spec and backend reference.
2. Ensure backend node resources exist.
3. Wait for node addresses and SSH reachability.
4. Bootstrap the first control plane node with the requested k0s version.
5. Join additional control plane and worker nodes.
6. Write kubeconfig connection details.
7. Observe node readiness and reconcile drift.

The initial scaffold implements validation, managed-resource wiring, status fields, and a no-op planner. Real backend resource creation and SSH/k0s execution are the next implementation tasks.

## First Smoke Target

Use a single-control-plane k0s cluster on Proxmox first:

- distribution: `k0s`
- version: `v1.34.1+k0s`
- control plane replicas: `1`
- worker replicas: `1`
- backend: Proxmox provider config and Ubuntu or Rocky cloud-init template

vSphere should use the same `KubernetesCluster` API with only backend fields changed.
